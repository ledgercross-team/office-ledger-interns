import { expect, test } from '@playwright/test';

test('a saved theme applies before paint and the system scheme is followed otherwise', async ({ page }) => {
  await page.addInitScript(() => window.localStorage.setItem('ol-theme', 'dark'));
  await page.emulateMedia({ colorScheme: 'light' });
  await page.goto('/login');
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark');
  const bg = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  expect(bg).toBe('rgb(14, 22, 19)');
});

test('unknown routes show the full-page not-found state', async ({ page }) => {
  await page.goto('/this-route-does-not-exist');
  await expect(page.getByRole('heading', { level: 1, name: "We couldn't find that page." })).toBeVisible();
  await expect(page.getByRole('link', { name: 'Back to dashboard' })).toBeVisible();
});
